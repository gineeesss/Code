import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        int anio = scr.nextInt();
        System.out.println("Introduce año");
        if (anio%4 == 0 && anio%100==0){
            if(anio%400==0){
                System.out.println("El año" +anio+" es bisiesto");
            }
            else System.out.println("El año "+anio+" no es bisiesto");
        }else System.out.println("El año "+anio+" no es bisiesto");

        System.out.println(anio%4);
        System.out.println(anio%100);
        System.out.println(anio%400);
    }
}